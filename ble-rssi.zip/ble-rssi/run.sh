python3 main.py
